Dim fso, shell, gameDir, downloadURL, zipPath, batName
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

' 基础参数配置
gameDir = "D:\cs1.6"
downloadURL = "https://game.nobistudio.com/go-game-app/downloads/cs16_green.zip" ' 替换为你的本地或云端 CS1.6 绿色版游戏包直链
zipPath = "D:\cs1.6_setup.zip"
batName = "user_launch_config.bat"

' 1. 自动检测 D:\cs1.6 目录是否存在
If Not fso.FolderExists(gameDir) Then
    Dim btnPressed
    btnPressed = MsgBox("检测到您的电脑未安装 CS1.6 客户端，是否立即自动下载并配置？", 4 + 32, "CS1.6 网页大厅")
    
    If btnPressed = 6 Then ' 用户点击了“是”
        MsgBox "正在后台启动下载，请稍候... 下载完成后会自动打开 D 盘。", 64, "开始下载"
        
        ' 调用原生无权限限制的 PowerShell 在后台隐藏下载游戏包
        Dim psCmd
        psCmd = "powershell -WindowStyle Hidden -Command ""(New-Object Net.WebClient).DownloadFile('" & downloadURL & "', '" & zipPath & "')"""
        shell.Run psCmd, 0, True ' 0表示隐藏窗口，True表示同步等待
        
        MsgBox "游戏包已下载至 D 盘根目录！请将其解压并命名为 cs1.6，完成后即可在网页一键启动！", 64, "下载成功"
        shell.Run "explorer.exe D:\", 1
    End If
Else
    ' 2. 如果目录存在，直接呼唤 CS1.6 客户端
    shell.CurrentDirectory = gameDir
    shell.Run """hl.exe"" -game cstrike", 1, False
End If