@echo off
setlocal enabledelayedexpansion

:: 自动获取当前批处理文件所在的绝对路径
set "CURRENT_DIR=%~dp0"
set "CURRENT_DIR=!CURRENT_DIR:\=\\!"

:: 将 cs16:// 协议直接写入当前登录用户的注册表 (HKCU)，100% 不需要管理员权限
reg add "HKCU\Software\Classes\cs16" /v "" /d "URL:CS16 Protocol" /f
reg add "HKCU\Software\Classes\cs16" /v "URL Protocol" /d "" /f
reg add "HKCU\Software\Classes\cs16\shell\open\command" /v "" /d "wscript.exe \"!CURRENT_DIR!cs16_launcher.vbs\" \"%%1\"" /f

echo ======================================================
echo  [免密VBS版] 网页大厅激活脚本绑定成功！
echo  现在可以返回网页直接点击进入游戏。
echo ======================================================
pause